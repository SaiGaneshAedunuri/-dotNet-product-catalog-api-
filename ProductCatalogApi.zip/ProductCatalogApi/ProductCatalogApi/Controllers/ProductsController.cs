﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ProductCatalogApi.Data;

namespace ProductCatalogApi.Controllers
{
	[Route("api/products")]
	[ApiController]
	public class ProductsController : ControllerBase
	{
		private readonly AppDbContext _context;

		public ProductsController(AppDbContext context)
		{
			_context = context;
		}

		// 1️ GetProduct
		[HttpGet("{id}")]
		public async Task<IActionResult> GetProduct(int id)
		{
			try
			{
				var product = await _context.Products.FindAsync(id);

				if (product == null)
					return NotFound("Product not found");

				return Ok(product);
			}
			catch (Exception ex)
			{
				return StatusCode(500, ex.Message);
			}
		}

		// 2️ GetProducts (Order by rating desc)
		[HttpGet]
		public async Task<IActionResult> GetProducts()
		{
			try
			{
				var products = await _context.Products
					.OrderByDescending(p => p.AverageCustomerRating)
					.ToListAsync();

				return Ok(products);
			}
			catch (Exception ex)
			{
				return StatusCode(500, ex.Message);
			}
		}

		// 3️ GetProductAttributes
		[HttpGet("{id}/attributes")]
		public async Task<IActionResult> GetProductAttributes(int id)
		{
			try
			{
				var attributes = await _context.ProductAttributes
					.Where(a => a.ProductId == id)
					.ToListAsync();

				return Ok(attributes);
			}
			catch (Exception ex)
			{
				return StatusCode(500, ex.Message);
			}
		}
	}
}