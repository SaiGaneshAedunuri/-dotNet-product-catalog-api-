﻿namespace ProductCatalogApi.DTOs
{
	public class ProductDto
	{
		public int ProductId { get; set; }

		public string ProductName { get; set; }

		public decimal PricePerItem { get; set; }

		public double AverageCustomerRating { get; set; }
	}
}