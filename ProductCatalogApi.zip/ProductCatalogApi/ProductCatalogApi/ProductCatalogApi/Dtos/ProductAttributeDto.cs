﻿namespace ProductCatalogApi.DTOs
{
	public class ProductAttributeDto
	{
		public string AttributeName { get; set; }

		public string AttributeValue { get; set; }
	}
}