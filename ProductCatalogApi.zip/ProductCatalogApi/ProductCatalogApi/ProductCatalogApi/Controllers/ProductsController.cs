﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ProductCatalogApi.Data;
using ProductCatalogApi.DTOs;
using Swashbuckle.AspNetCore.Annotations;

namespace ProductCatalogApi.Controllers
{
	[Route("api/products")]
	[ApiController]
	public class ProductsController : ControllerBase
	{
		private readonly AppDbContext _context;

		public ProductsController(AppDbContext context)
		{
			_context = context;
		}

		/// <summary>
		/// Get single product by id
		/// </summary>
		/// <param name="id">Product Id</param>
		/// <returns>Product Details</returns>
		[HttpGet("{id}")]
		[SwaggerOperation(Summary = "Get product by id")]
		[SwaggerResponse(200, "Product found")]
		[SwaggerResponse(400, "Invalid product id")]
		[SwaggerResponse(404, "Product not found")]
		[SwaggerResponse(500, "Internal server error")]
		public async Task<IActionResult> GetProduct(int id)
		{
			try
			{
				if (id <= 0)
					return BadRequest("Invalid product id");

				var product = await _context.Products
					.Where(p => p.ProductId == id)
					.Select(p => new ProductDto
					{
						ProductId = p.ProductId,
						ProductName = p.ProductName,
						PricePerItem = p.PricePerItem,
						AverageCustomerRating = p.AverageCustomerRating
					})
					.FirstOrDefaultAsync();

				if (product == null)
					return NotFound("Product not found");

				return Ok(product);
			}
			catch
			{
				return StatusCode(500, "Something went wrong");
			}
		}

		/// <summary>
		/// Get all products sorted by rating
		/// </summary>
		[HttpGet]
		[SwaggerOperation(Summary = "Get all products")]
		[SwaggerResponse(200, "Products list")]
		[SwaggerResponse(500, "Internal server error")]
		public async Task<IActionResult> GetProducts()
		{
			try
			{
				var products = await _context.Products
					.OrderByDescending(p => p.AverageCustomerRating)
					.Select(p => new ProductDto
					{
						ProductId = p.ProductId,
						ProductName = p.ProductName,
						PricePerItem = p.PricePerItem,
						AverageCustomerRating = p.AverageCustomerRating
					})
					.ToListAsync();

				return Ok(products);
			}
			catch
			{
				return StatusCode(500, "Something went wrong");
			}
		}

		/// <summary>
		/// Get attributes of a product
		/// </summary>
		/// <param name="id">Product Id</param>
		[HttpGet("{id}/attributes")]
		[SwaggerOperation(Summary = "Get product attributes")]
		[SwaggerResponse(200, "Attributes list")]
		[SwaggerResponse(400, "Invalid product id")]
		[SwaggerResponse(404, "Product not found")]
		[SwaggerResponse(500, "Internal server error")]
		public async Task<IActionResult> GetProductAttributes(int id)
		{
			try
			{
				if (id <= 0)
					return BadRequest("Invalid product id");

				var productExists = await _context.Products
					.AnyAsync(p => p.ProductId == id);

				if (!productExists)
					return NotFound("Product not found");

				var attributes = await _context.ProductAttributes
					.Where(a => a.ProductId == id)
					.Select(a => new ProductAttributeDto
					{
						AttributeName = a.AttributeName,
						AttributeValue = a.AttributeValue
					})
					.ToListAsync();

				return Ok(attributes);
			}
			catch
			{
				return StatusCode(500, "Something went wrong");
			}
		}
	}
}