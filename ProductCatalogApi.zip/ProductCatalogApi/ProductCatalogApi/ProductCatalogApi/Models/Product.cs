﻿using Microsoft.AspNetCore.Mvc;

namespace ProductCatalogApi.Models
{
	public class Product
	{
		public int ProductId { get; set; }

		public string ProductName { get; set; }

		public decimal PricePerItem { get; set; }

		public double AverageCustomerRating { get; set; }

		public ICollection<ProductAttribute> Attributes { get; set; }
	}
}
