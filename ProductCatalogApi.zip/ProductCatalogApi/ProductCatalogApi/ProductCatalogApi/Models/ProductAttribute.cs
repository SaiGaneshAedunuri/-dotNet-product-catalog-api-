﻿namespace ProductCatalogApi.Models
{
	public class ProductAttribute
	{
		public int ProductAttributeId { get; set; }

		public string AttributeName { get; set; }

		public string AttributeValue { get; set; }

		public int ProductId { get; set; }

		public Product Product { get; set; }
	}
}
