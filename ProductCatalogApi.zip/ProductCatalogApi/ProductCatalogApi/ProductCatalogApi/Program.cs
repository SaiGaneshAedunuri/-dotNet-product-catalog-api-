using Microsoft.EntityFrameworkCore;
using ProductCatalogApi.Data;
using ProductCatalogApi.Models;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllers();

builder.Services.AddDbContext<AppDbContext>(options =>
	options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c =>
{
	c.EnableAnnotations();

	var xmlFile = $"{System.Reflection.Assembly.GetExecutingAssembly().GetName().Name}.xml";
	var xmlPath = Path.Combine(AppContext.BaseDirectory, xmlFile);
	c.IncludeXmlComments(xmlPath);
});

var app = builder.Build();

app.UseSwagger();
app.UseSwaggerUI();

app.UseHttpsRedirection();
app.UseAuthorization();

app.MapControllers();

using (var scope = app.Services.CreateScope())
{
	var context = scope.ServiceProvider.GetRequiredService<AppDbContext>();

	if (!context.Products.Any())
	{
		context.Products.AddRange(
			new Product
			{
				ProductName = "Laptop",
				PricePerItem = 60000,
				AverageCustomerRating = 4.5
			},
			new Product
			{
				ProductName = "Mobile",
				PricePerItem = 20000,
				AverageCustomerRating = 4.8
			}
		);

		context.SaveChanges();

		context.ProductAttributes.AddRange(
			new ProductAttribute
			{
				ProductId = 1,
				AttributeName = "Color",
				AttributeValue = "Black"
			},
			new ProductAttribute
			{
				ProductId = 1,
				AttributeName = "Width",
				AttributeValue = "15 inch"
			}
		);

		context.SaveChanges();
	}
}

app.Run();